const activeTabTitle = document.getElementById("active-tab-title");
const activeTabUrl = document.getElementById("active-tab-url");
const tabWarning = document.getElementById("tab-warning");
const startSessionButton = document.getElementById("start-session");

function isCapturableTab(tab) {
  if (!tab?.id || !tab.url) return false;

  return tab.url.startsWith("https://meet.google.com/");
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab ?? null;
}

async function loadActiveTab() {
  const tab = await getActiveTab();
  activeTabTitle.textContent = tab?.title ?? "aba nao encontrada";
  activeTabUrl.textContent = tab?.url ?? "";

  if (!isCapturableTab(tab)) {
    startSessionButton.disabled = true;
    tabWarning.textContent =
      "Abra uma chamada ativa no Google Meet antes de iniciar a captura.";
    return;
  }

  startSessionButton.disabled = false;
  tabWarning.textContent =
    "Ao iniciar, a extensao abre a captura da sessao e o navegador pede para compartilhar a aba do Meet com audio.";
}

document.getElementById("start-session").addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (!isCapturableTab(tab)) {
    return;
  }

  await chrome.runtime.sendMessage({
    type: "session:open-page",
    target: "background",
    tabId: tab.id,
  });
  window.close();
});

void loadActiveTab();
